package Lesson18;

/**
 * Created by Marina on 30.7.2017 г..
 */
public interface IElectronicDevice {
    public void start();
    public void stop();
    public boolean isStarted=false;
}
