package Cakes;

/**
 * Created by Marina on 27.8.2017 г..
 */
public class Voucher {
    private int value=
}
