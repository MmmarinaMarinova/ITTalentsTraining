package Lesson13.Task01;

import java.util.function.Consumer;

/**
 * Created by Marina on 11.7.2017 г..
 */
public class ComputerDemo {
    public static void main(String[] args) {
        /*Да се създадат 2 обекта от тип Computer.
        Да се зададат стойности на всеки от компютрите за year, price,
        hardDiskMemory, freeMemory, operationSystem.Нека единият компютър
        да е лаптоп. На единия от двата компютъра да се задели памет 100
        (чрез метода useMemory), а на другия, да се смени операционната
        система (чрез метода changeOperationSystem), след което да се
        изведат на екрана всичките полета на двата компютъра*/

        Computer pc=new Computer();
        pc.year=2015;
        pc.operationSystem="Win7";
        pc.isNotebook=false;
        pc.hardDiskMemory=1000;
        pc.freeMemory=578;

        Computer laptop=new Computer();
        laptop.year=2017;
        laptop.operationSystem="Win10";
        laptop.isNotebook=true;
        laptop.hardDiskMemory=1500;
        laptop.freeMemory=813;

        laptop.useMemory(100);
        pc.changeOperationSystem("Win10");

        System.out.println("Parameters of the personal computer: ");
        System.out.println("Year: "+pc.year+" Operation system: "+pc.operationSystem+
        " is it notebook: "+pc.isNotebook+" hard disk memory: "+pc.hardDiskMemory+ " free memory: "+pc.freeMemory);

        System.out.println("Parameters of the laptop: ");
        System.out.println("Year: "+laptop.year+" Operation system: "+laptop.operationSystem+
                " is it notebook: "+laptop.isNotebook+" hard disk memory: "+laptop.hardDiskMemory+" free memory: "+laptop.freeMemory);
    }
}
