package Lesson13.Task01;

/**
 * Created by Marina on 11.7.2017 г..
 */
public class Computer {

   int year;
   double price;
   boolean isNotebook;
   int hardDiskMemory; //GB
    int freeMemory;
    String operationSystem;


void changeOperationSystem( String newOperationSystem){
    operationSystem=newOperationSystem;
}

void useMemory(int memory){
    if(memory>freeMemory){
        System.out.println("Not enough free memory!");
        return;
    }
    freeMemory-=memory;
}

}
