package Lesson13.Task02;

/**
 * Created by Marina on 11.7.2017 г..
 */
public class Call {

    double priceForAMinute=0.25;
    GSM caller;
    GSM receiver;
    int duration; //minutes
}
