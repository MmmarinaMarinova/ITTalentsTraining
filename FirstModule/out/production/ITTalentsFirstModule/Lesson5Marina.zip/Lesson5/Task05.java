package Lesson5;

/**
 * Created by Marina on 10.6.2017 г..
 */
public class Task05 {
    public static void main(String[] args) {
        int[] array = new int[10];
        for (int i = 0; i < 10; i++) {
            array[i] = i * 3;
            System.out.print(array[i] + " ");
        }

    }
}
