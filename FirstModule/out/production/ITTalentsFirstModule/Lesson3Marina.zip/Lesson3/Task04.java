package Lesson3;

/**
 * Created by Marina on 2.6.2017 г..
 */
public class Task04 {
    public static void main(String[] args) {
        for (int i = 10; i > 0; i--) {
            System.out.println(i);
        }
    }
}
