package Lesson3;

/**
 * Created by Marina on 2.6.2017 г..
 */
public class Task02 {
    public static void main(String[] args) {
        for (int i = -20; i <= 50; i++) {
            System.out.println(i);
        }
    }
}
