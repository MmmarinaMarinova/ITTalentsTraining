package Lesson3;

/**
 * Created by Marina on 2.6.2017 г..
 */
public class Task03 {
    public static void main(String[] args) {
        for (int i = -9; i <= 10; i += 2) {
            System.out.println(i);
        }

    }
}